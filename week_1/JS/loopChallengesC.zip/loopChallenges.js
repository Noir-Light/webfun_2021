// function oddNum() {
//     for (let i = 1; i < 20; i++) {
//         if (i % 2 !== 0) {
//             console.log(i);
//         }
//     }
// }
// oddNum();

// decreasing by 3 100 to 0
// function countDown() {
//     for (let i = 100; i > 0; i--) {
//         if (i % 3 == 0) {
//             console.log(i);
//         }
//     }
// }
// countDown();

// console.log(9 % 3 == 0);


// for (var i = 4; i >= -3.5; i -= 1.5) {
//     console.log(i);
// }

// var sum = 0;
// for (var i = 1; i <= 100; i++){
//     sum += i;
// }
// console.log(sum);


// var product = 1;
// for (var i = 1; i <= 12; i++){
//     product *= i;
// }
// console.log(product);


