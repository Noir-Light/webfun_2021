//console.log("is this working")
//var click = 0
//function alert(cart) {
    //console.log("your cart is empty")
//}

// function hover(element) {

//     element.src = "succulents-2.jpg"

//     console.log("mouseover")
// }



function hover(element) {

    if(element.src == "succulents-1.jpg"){
        element.src = "succulents-2.jpg"

    }
else{
    element.src = "succulents-2.jpg"
}
}   


    console.log("mouseover")




// var click = 0

// function hide(element) {
    // element.remove()
// }