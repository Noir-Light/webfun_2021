// console.log("is this working")
var click = 0
function alert(cart){
    console.log("your cart is empty")
}