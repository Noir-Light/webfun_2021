var click = 0

function loginNLogout(element) {

    if (element.innerText == "Login") {
        element.innerText = "Logout"

    }
    else {
        element.innerText = "Login"
    }
}


var click = 0
function countLikes(element) {
    click++
    element.innerText = click + "likes"

}

var click = 0

function removeText(element) {
    if (element.innerText == "Add definition") {
        element.innerText = ""

}
else {
    element.innerText = "Add definition"
}
}
