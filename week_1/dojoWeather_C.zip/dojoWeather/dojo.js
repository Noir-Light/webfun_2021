// console.log("hi");

function myAlert(){
    alert(' Loading weather report...')
}


function removeElement(){
    document.querySelector(".alert").remove();
}


function handleScaleChange(elem){
//     var hi = document.querySelector("#hi span");
//     var lo = document.querySelector("#lo span");
//     var temperatureHi = (hi * (9/5)) + 32;
//     var temperatureLo = (lo* (9/5)) + 32;
//     lo.innerText = temperatureLo;
//     hi.innerText = temperatureHi;
    for(var i = 0; i < degreeList.length; i++){
        console.log(degreeList[i].innerHTML);
        if(elem.value == "f"){
            degreeList[i].innerHTML = Math.floor((degreeList[i].innerHTML * 9 / 5) + 32);
        } else{
            degreeList[i].innerHTML = Math.floor((degreeList[i].innerHTML  - 32) * 5 / 9);
        }
    }
    console.log(elem.value);
}


var degreeList = document.getElementsByClassName("degree");
console.log(degreeList);
console.log(degreeList[0].innerHTML);

// function toCelsius(fahrenheit) {   
//   let temp = (fahrenheit - 32) * 5 / 9; 
// return Math.round(temp*10) / 10;  
// }
// function toFahrenheit(celsius) {
// return Math.round(temp*10) / 10;
// }
