function over(element) {
    element.scr =  kitsune2.jfif("mouseover");
        
}
    
function out(element) {
    element.scr =kitsune1.jpg("mouseout");    
}


