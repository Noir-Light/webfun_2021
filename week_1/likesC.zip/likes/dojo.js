
var click = 0;
function countLikes1(element) {
    click++
    element.innerText = click + "Likes"
}



var click1 = 0;
function countLikes2(element) {
    click1++
    element.innerText = click1 + "Likes"
}



var click2 = 0;
function countLikes3(element) {
    click2++
    element.innerText = click2 + "Likes"
}


// var click = 0;
// function countLikes(element){
//     click += 1;
//     element.innerText = click + "Likes";
// }
