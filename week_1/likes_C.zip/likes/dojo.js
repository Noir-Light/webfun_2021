var click = 0

function countLikes(element) {
    click++
    element.innerText = click + "Likes"
}